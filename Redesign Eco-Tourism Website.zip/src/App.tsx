import { useState, useEffect, useRef } from 'react'
import img0 from '@/imports/image.png'
import img1 from '@/imports/image-1.png'
import img2 from '@/imports/image-2.png'

// ─── Icons ────────────────────────────────────────────────────────────────────

function LeafIcon({ className = '' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10z" />
      <path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12" />
    </svg>
  )
}

function MenuIcon({ className = '' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <line x1="3" y1="6" x2="21" y2="6" />
      <line x1="3" y1="12" x2="21" y2="12" />
      <line x1="3" y1="18" x2="21" y2="18" />
    </svg>
  )
}

function XIcon({ className = '' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <line x1="18" y1="6" x2="6" y2="18" />
      <line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  )
}

function ArrowRightIcon({ className = '' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="5" y1="12" x2="19" y2="12" />
      <polyline points="12 5 19 12 12 19" />
    </svg>
  )
}

function ChevronDownIcon({ className = '' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="6 9 12 15 18 9" />
    </svg>
  )
}

// ─── Navbar ───────────────────────────────────────────────────────────────────

function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const navLinks = [
    { label: 'Tours', href: '#tours' },
    { label: 'Destinations', href: '#destinations' },
    { label: 'About', href: '#about' },
    { label: 'Gallery', href: '#gallery' },
    { label: 'Contact', href: '#contact' },
  ]

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
      style={{
        backgroundColor: scrolled ? '#f5f0e8' : 'transparent',
        borderBottom: scrolled ? '1px solid #d4cbbf' : 'none',
        boxShadow: scrolled ? '0 2px 20px rgba(0,0,0,0.06)' : 'none',
      }}
    >
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2 group">
          <div
            className="w-9 h-9 rounded-full flex items-center justify-center transition-colors"
            style={{ backgroundColor: scrolled ? '#2d5a27' : 'rgba(255,255,255,0.15)' }}
          >
            <LeafIcon className={`w-5 h-5 ${scrolled ? 'text-[#f5f0e8]' : 'text-white'}`} />
          </div>
          <span
            className="font-display font-semibold text-lg tracking-tight transition-colors"
            style={{ color: scrolled ? '#1a1a14' : 'white' }}
          >
            Gialai Eco Tourist
          </span>
        </a>

        {/* Desktop links */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="text-sm font-medium transition-colors hover:opacity-70"
              style={{ color: scrolled ? '#1a1a14' : 'rgba(255,255,255,0.9)' }}
            >
              {l.label}
            </a>
          ))}
          <a
            href="#contact"
            className="ml-2 px-5 py-2 text-sm font-semibold rounded transition-all"
            style={{
              backgroundColor: scrolled ? '#2d5a27' : 'rgba(255,255,255,0.15)',
              color: 'white',
              border: scrolled ? 'none' : '1px solid rgba(255,255,255,0.5)',
            }}
          >
            Book Now
          </a>
        </div>

        {/* Mobile toggle */}
        <button
          className="md:hidden p-2"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          {menuOpen
            ? <XIcon className={`w-6 h-6 ${scrolled ? 'text-[#1a1a14]' : 'text-white'}`} />
            : <MenuIcon className={`w-6 h-6 ${scrolled ? 'text-[#1a1a14]' : 'text-white'}`} />
          }
        </button>
      </div>

      {/* Mobile drawer */}
      {menuOpen && (
        <div className="md:hidden bg-[#f5f0e8] border-t border-[#d4cbbf] px-6 py-4 flex flex-col gap-4">
          {navLinks.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="text-sm font-medium text-[#1a1a14] hover:text-[#2d5a27] transition-colors"
              onClick={() => setMenuOpen(false)}
            >
              {l.label}
            </a>
          ))}
          <a
            href="#contact"
            className="w-full text-center py-3 text-sm font-semibold rounded bg-[#2d5a27] text-white"
            onClick={() => setMenuOpen(false)}
          >
            Book Now
          </a>
        </div>
      )}
    </nav>
  )
}

// ─── Hero ─────────────────────────────────────────────────────────────────────

function Hero() {
  return (
    <section className="relative min-h-screen flex flex-col justify-center overflow-hidden">
      {/* Background */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url(https://images.unsplash.com/photo-1603269414002-7f3d2acd0409?w=1600&h=1000&fit=crop&auto=format)`,
          backgroundColor: '#1a2e1a',
        }}
      />
      {/* Gradient overlay */}
      <div
        className="absolute inset-0"
        style={{
          background: 'linear-gradient(to bottom, rgba(10,20,10,0.55) 0%, rgba(10,20,10,0.35) 50%, rgba(10,20,10,0.7) 100%)',
        }}
      />

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 pt-32 pb-16 flex flex-col gap-6">
        <div className="inline-flex items-center gap-2 text-xs font-medium tracking-widest uppercase text-white/60">
          <span
            className="inline-block w-6 h-px"
            style={{ backgroundColor: 'rgba(255,255,255,0.4)' }}
          />
          Du Lịch Sinh Thái Gia Lai
        </div>

        <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-tight max-w-3xl">
          Explore the wild heart of the Central Highlands
        </h1>

        <p className="text-white/75 text-base sm:text-lg max-w-xl leading-relaxed">
          Small-group treks through primeval forests, nights under highland stars, and authentic stays in Bahnar and Jarai villages — designed by locals who know every trail.
        </p>

        <div className="flex flex-wrap gap-4 mt-2">
          <a
            href="#tours"
            className="group flex items-center gap-2 px-7 py-3.5 text-sm font-semibold rounded transition-all"
            style={{ backgroundColor: '#2d5a27', color: '#f5f0e8' }}
          >
            View Tours
            <ArrowRightIcon className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </a>
          <a
            href="#contact"
            className="flex items-center gap-2 px-7 py-3.5 text-sm font-semibold rounded border transition-all"
            style={{ borderColor: 'rgba(255,255,255,0.5)', color: 'white' }}
          >
            Contact Us
          </a>
        </div>

        {/* Stats */}
        <div className="flex flex-wrap gap-8 mt-8 pt-8" style={{ borderTop: '1px solid rgba(255,255,255,0.15)' }}>
          {[
            { value: '26+', label: 'Tours' },
            { value: '12', label: 'Years of Experience' },
            { value: '4.8', label: 'Rating' },
            { value: '500+', label: 'Happy Travelers' },
          ].map((s) => (
            <div key={s.label} className="flex flex-col gap-1">
              <span className="font-display text-2xl font-bold text-white">{s.value}</span>
              <span className="text-xs uppercase tracking-widest text-white/50">{s.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll hint */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 text-white/40 text-xs tracking-widest">
        <span className="uppercase">Scroll</span>
        <ChevronDownIcon className="w-4 h-4 animate-bounce" />
      </div>
    </section>
  )
}

// ─── About ────────────────────────────────────────────────────────────────────

function About() {
  return (
    <section id="about" className="py-24 bg-[#f5f0e8]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          {/* Text */}
          <div className="flex flex-col gap-6">
            <div className="text-xs font-semibold tracking-widest uppercase text-[#8b5e3c]">
              About Us
            </div>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#1a1a14] leading-tight">
              Local roots,<br />
              <em>sustainable paths.</em>
            </h2>
            <p className="text-[#4a4035] leading-relaxed text-base">
              Founded in 2012 by a team of passionate Gia Lai locals, Gialai Eco Tourist has spent over a decade crafting journeys through the Central Highlands that are as responsible as they are unforgettable. We work hand-in-hand with Bahnar and Jarai communities, ensuring that tourism directly benefits the people who call these highlands home.
            </p>
            <p className="text-[#4a4035] leading-relaxed text-base">
              Every itinerary is designed with a light footprint in mind — small groups, trained local guides, and accommodations that support, not exploit, the natural environment. We are fully licensed by the Vietnam National Administration of Tourism and certified in eco-tourism best practices.
            </p>
            {/* Badges */}
            <div className="flex flex-wrap gap-3 mt-2">
              {['Licensed by VNAT', 'Eco-Certified', 'Community Partner', 'Since 2012'].map((b) => (
                <span
                  key={b}
                  className="px-4 py-1.5 text-xs font-semibold rounded-full border"
                  style={{ borderColor: '#2d5a27', color: '#2d5a27', backgroundColor: 'rgba(45,90,39,0.06)' }}
                >
                  {b}
                </span>
              ))}
            </div>
          </div>

          {/* Photo */}
          <div className="relative">
            <div
              className="absolute -top-4 -left-4 w-full h-full rounded"
              style={{ border: '1px solid #d4cbbf' }}
            />
            <img
              src="https://images.unsplash.com/photo-1731119347526-a51ad22763cd?w=800&h=600&fit=crop&auto=format"
              alt="Aerial view of lush green Gia Lai valley"
              className="relative w-full object-cover rounded"
              style={{ aspectRatio: '4/3' }}
            />
            <div
              className="absolute bottom-6 left-6 rounded px-5 py-4"
              style={{ backgroundColor: 'rgba(10,20,10,0.75)', backdropFilter: 'blur(8px)' }}
            >
              <div className="font-display text-2xl font-bold text-white">12+ Years</div>
              <div className="text-xs text-white/60 mt-0.5">Serving the Central Highlands</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

// ─── Tour Packages ────────────────────────────────────────────────────────────

type Difficulty = 'Easy' | 'Moderate' | 'Hard'

interface Tour {
  id: number
  title: string
  category: string
  duration: string
  difficulty: Difficulty
  price: string
  image: string
  description: string
}

const tours: Tour[] = [
  {
    id: 1,
    title: 'Kon Ka Kinh Forest Trek',
    category: 'Trekking',
    duration: '3 days / 2 nights',
    difficulty: 'Moderate',
    price: 'From $89',
    image: 'https://images.unsplash.com/photo-1585970661791-9cec67470281?w=600&h=400&fit=crop&auto=format',
    description: 'Traverse old-growth forests in the UNESCO-recognized Kon Ka Kinh Biosphere Reserve with a local ranger.',
  },
  {
    id: 2,
    title: 'Biển Hồ Camping Night',
    category: 'Camping',
    duration: '2 days / 1 night',
    difficulty: 'Easy',
    price: 'From $65',
    image: 'https://images.unsplash.com/photo-1778381464400-3dd0d3eb0591?w=600&h=400&fit=crop&auto=format',
    description: 'Lakeside camping beside the iconic volcanic crater lake, with sunset cooking and highland stargazing.',
  },
  {
    id: 3,
    title: 'Ba Hồ Kayaking Adventure',
    category: 'Kayaking',
    duration: '1 day',
    difficulty: 'Easy',
    price: 'From $45',
    image: 'https://images.unsplash.com/photo-1543411789-1a67a2ac05c6?w=600&h=400&fit=crop&auto=format',
    description: 'Paddle through calm jungle rivers, passing through tiered waterfalls and dense forest canopy.',
  },
  {
    id: 4,
    title: 'Bahnar Village Homestay',
    category: 'Village',
    duration: '2 days / 1 night',
    difficulty: 'Easy',
    price: 'From $75',
    image: 'https://images.unsplash.com/photo-1767924280511-46d98bca2da3?w=600&h=400&fit=crop&auto=format',
    description: 'Stay with a Bahnar family, join rice planting, learn traditional weaving, and share a communal dinner.',
  },
  {
    id: 5,
    title: 'Central Highlands Cultural Tour',
    category: 'Cultural',
    duration: '4 days / 3 nights',
    difficulty: 'Easy',
    price: 'From $120',
    image: 'https://images.unsplash.com/photo-1773393893547-968a10d584c5?w=600&h=400&fit=crop&auto=format',
    description: 'A curated route through coffee highlands, ethnic markets, rông houses, and ancient gong ceremonies.',
  },
  {
    id: 6,
    title: 'Kon Chư Răng Expedition',
    category: 'Trekking',
    duration: '5 days / 4 nights',
    difficulty: 'Hard',
    price: 'From $180',
    image: 'https://images.unsplash.com/photo-1696276959983-2da1448e695a?w=600&h=400&fit=crop&auto=format',
    description: 'A multi-day wilderness expedition into Kon Chư Răng Nature Reserve — remote trails, river crossings, wild camping.',
  },
]

const difficultyColor: Record<Difficulty, string> = {
  Easy: '#2d5a27',
  Moderate: '#8b5e3c',
  Hard: '#c0392b',
}

function TourCard({ tour }: { tour: Tour }) {
  return (
    <div
      className="flex flex-col rounded overflow-hidden group cursor-pointer transition-all hover:-translate-y-1"
      style={{ backgroundColor: '#ffffff', border: '1px solid #d4cbbf', boxShadow: '0 2px 12px rgba(0,0,0,0.04)' }}
    >
      <div className="relative overflow-hidden" style={{ aspectRatio: '4/3' }}>
        <img
          src={tour.image}
          alt={tour.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <span
          className="absolute top-3 left-3 px-3 py-1 text-xs font-semibold rounded-full text-white"
          style={{ backgroundColor: difficultyColor[tour.difficulty] }}
        >
          {tour.difficulty}
        </span>
        <span
          className="absolute top-3 right-3 px-3 py-1 text-xs font-medium rounded-full"
          style={{ backgroundColor: 'rgba(245,240,232,0.9)', color: '#4a4035' }}
        >
          {tour.category}
        </span>
      </div>
      <div className="flex flex-col gap-3 p-5 flex-1">
        <h3 className="font-display font-semibold text-lg text-[#1a1a14] leading-snug">{tour.title}</h3>
        <p className="text-sm text-[#7a6f60] leading-relaxed flex-1">{tour.description}</p>
        <div className="flex items-center justify-between pt-2" style={{ borderTop: '1px solid #ede8dc' }}>
          <div className="flex flex-col gap-0.5">
            <span className="text-xs text-[#7a6f60]">{tour.duration}</span>
            <span className="font-semibold text-[#2d5a27]">{tour.price}</span>
          </div>
          <button
            className="flex items-center gap-1.5 text-sm font-semibold text-[#2d5a27] hover:gap-2.5 transition-all"
          >
            Details <ArrowRightIcon className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  )
}

function TourPackages() {
  const categories = ['All', 'Trekking', 'Camping', 'Kayaking', 'Village', 'Cultural']
  const [active, setActive] = useState('All')

  const filtered = active === 'All' ? tours : tours.filter((t) => t.category === active)

  return (
    <section id="tours" className="py-24" style={{ backgroundColor: '#ede8dc' }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col gap-4 mb-12">
          <div className="text-xs font-semibold tracking-widest uppercase text-[#8b5e3c]">Tour Packages</div>
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#1a1a14] leading-tight max-w-lg">
              Find your next <em>highland adventure.</em>
            </h2>
            {/* Filter tabs */}
            <div className="flex flex-wrap gap-2">
              {categories.map((c) => (
                <button
                  key={c}
                  onClick={() => setActive(c)}
                  className="px-4 py-2 text-sm font-medium rounded-full transition-all"
                  style={{
                    backgroundColor: active === c ? '#2d5a27' : '#ffffff',
                    color: active === c ? '#f5f0e8' : '#4a4035',
                    border: `1px solid ${active === c ? '#2d5a27' : '#d4cbbf'}`,
                  }}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((t) => <TourCard key={t.id} tour={t} />)}
        </div>
      </div>
    </section>
  )
}

// ─── Destinations ──────────────────────────────────────────────────────────────

const destinations = [
  {
    name: 'Biển Hồ',
    subtitle: 'Volcanic Crater Lake',
    description: 'Known as the "Eye of Pleiku", this ethereal lake sits inside an ancient volcanic crater surrounded by pine forest.',
    image: 'https://images.unsplash.com/photo-1663564000694-a440edf76cd9?w=800&h=600&fit=crop&auto=format',
    span: 'col-span-2 row-span-2',
  },
  {
    name: 'Kon Ka Kinh',
    subtitle: 'UNESCO Biosphere Reserve',
    description: 'Vast primary forest home to rare primates, hornbills, and undisturbed highland ecosystems.',
    image: 'https://images.unsplash.com/photo-1585970661791-9cec67470281?w=600&h=400&fit=crop&auto=format',
    span: '',
  },
  {
    name: 'Kon Chư Răng',
    subtitle: 'Nature Reserve',
    description: 'Remote and rugged — a true frontier for serious trekkers and wildlife enthusiasts.',
    image: 'https://images.unsplash.com/photo-1695094412603-3340f1e72232?w=600&h=400&fit=crop&auto=format',
    span: '',
  },
  {
    name: 'Ia Grai Waterfalls',
    subtitle: 'Highland Cascades',
    description: 'A series of wild waterfalls plunging through red-rock gorges, accessible by a short jungle hike.',
    image: 'https://images.unsplash.com/photo-1686766219304-5e2fb0df9d2d?w=600&h=400&fit=crop&auto=format',
    span: '',
  },
  {
    name: 'Bahnar Villages',
    subtitle: 'Ethnic Minority Culture',
    description: 'Traditional stilt houses, communal rông halls, handwoven cloth, and the living culture of the Bahnar people.',
    image: 'https://images.unsplash.com/photo-1767924280511-46d98bca2da3?w=600&h=400&fit=crop&auto=format',
    span: '',
  },
]

function Destinations() {
  return (
    <section id="destinations" className="py-24 bg-[#f5f0e8]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col gap-4 mb-12">
          <div className="text-xs font-semibold tracking-widest uppercase text-[#8b5e3c]">Destinations</div>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-[#1a1a14] leading-tight max-w-2xl">
            Places that take your breath — <em>and give it back.</em>
          </h2>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 auto-rows-[280px]">
          {destinations.map((d, i) => (
            <div
              key={d.name}
              className={`relative rounded overflow-hidden group cursor-pointer ${i === 0 ? 'lg:col-span-2 lg:row-span-2' : ''}`}
              style={{ backgroundColor: '#1a2e1a' }}
            >
              <img
                src={d.image}
                alt={d.name}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-80"
              />
              <div
                className="absolute inset-0 transition-opacity duration-300"
                style={{
                  background: 'linear-gradient(to top, rgba(10,20,10,0.85) 0%, rgba(10,20,10,0.1) 60%)',
                }}
              />
              {/* Hover overlay */}
              <div
                className="absolute inset-0 p-6 flex flex-col justify-end opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{ background: 'rgba(10,20,10,0.6)' }}
              >
                <p className="text-white/80 text-sm leading-relaxed">{d.description}</p>
              </div>
              <div className="absolute bottom-0 left-0 right-0 p-6 group-hover:opacity-0 transition-opacity duration-300">
                <div className="text-xs text-white/50 tracking-widest uppercase mb-1">{d.subtitle}</div>
                <h3 className="font-display text-2xl font-bold text-white">{d.name}</h3>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── Why Choose Us ────────────────────────────────────────────────────────────

const features = [
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
      </svg>
    ),
    title: 'Safety First',
    desc: 'All guides certified in wilderness first aid. Every route risk-assessed and insured.',
  },
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7">
        <circle cx="12" cy="12" r="10" /><path d="M12 8v4l3 3" />
      </svg>
    ),
    title: 'Local Expert Guides',
    desc: 'Born-and-raised highland guides who speak the land — and the people on it.',
  },
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" />
      </svg>
    ),
    title: 'Small Groups',
    desc: 'Maximum 12 people per departure. Intimate, attentive, and low-impact.',
  },
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7">
        <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10z" />
        <path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12" />
      </svg>
    ),
    title: 'Eco-Friendly Practices',
    desc: 'Leave-no-trace principles, biodegradable gear, and community-built campsites.',
  },
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7">
        <rect x="3" y="11" width="18" height="11" rx="2" ry="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" />
      </svg>
    ),
    title: 'Fully Licensed',
    desc: 'Registered with Vietnam National Administration of Tourism. All tours insured.',
  },
  {
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7">
        <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
      </svg>
    ),
    title: '100% Customizable',
    desc: 'Private departures, custom routes, extended stays — designed around your group.',
  },
]

function WhyChooseUs() {
  return (
    <section className="py-24" style={{ backgroundColor: '#1a2e1a' }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-14">
          <div className="text-xs font-semibold tracking-widest uppercase text-[#8b9e6b] mb-4">Why Choose Us</div>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-white leading-tight">
            Travel that leaves <em>good tracks.</em>
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((f) => (
            <div key={f.title} className="flex flex-col gap-4 p-6 rounded" style={{ backgroundColor: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}>
              <div className="text-[#8b9e6b]">{f.icon}</div>
              <h3 className="font-display font-semibold text-lg text-white">{f.title}</h3>
              <p className="text-sm text-white/60 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── Gallery ──────────────────────────────────────────────────────────────────

const galleryItems = [
  { src: img0, caption: 'Early morning at Biển Hồ crater lake', tall: true },
  { src: img1, caption: 'Discovering trails through the Central Highlands', tall: false },
  { src: 'https://images.unsplash.com/photo-1778381464400-3dd0d3eb0591?w=700&h=900&fit=crop&auto=format', caption: 'Campsite in the green valley near Kon Ka Kinh', tall: true },
  { src: img2, caption: 'Journaling after a highland traverse', tall: false },
  { src: 'https://images.unsplash.com/photo-1543411789-1a67a2ac05c6?w=700&h=500&fit=crop&auto=format', caption: 'Paddling through jungle rivers', tall: false },
  { src: 'https://images.unsplash.com/photo-1767924280511-46d98bca2da3?w=700&h=900&fit=crop&auto=format', caption: 'Traditional weaving in a Bahnar village', tall: true },
  { src: 'https://images.unsplash.com/photo-1773393893547-968a10d584c5?w=700&h=500&fit=crop&auto=format', caption: 'Meeting locals on the mountain terraces', tall: false },
  { src: 'https://images.unsplash.com/photo-1696276959983-2da1448e695a?w=700&h=500&fit=crop&auto=format', caption: 'Remote village at the foot of the highlands', tall: false },
  { src: 'https://images.unsplash.com/photo-1695094412603-3340f1e72232?w=700&h=900&fit=crop&auto=format', caption: 'River valley deep inside Kon Chư Răng', tall: true },
]

function Gallery() {
  return (
    <section id="gallery" className="py-24 bg-[#f5f0e8]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col gap-4 mb-12">
          <div className="text-xs font-semibold tracking-widest uppercase text-[#8b5e3c]">Gallery</div>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-[#1a1a14] leading-tight">
            Moments from <em>the trail.</em>
          </h2>
        </div>

        {/* Masonry-style CSS columns */}
        <div style={{ columns: 'var(--gallery-cols, 3)', gap: '1rem' }}>
          <style>{`
            @media (max-width: 640px) { :root { --gallery-cols: 1; } }
            @media (min-width: 641px) and (max-width: 1023px) { :root { --gallery-cols: 2; } }
            @media (min-width: 1024px) { :root { --gallery-cols: 3; } }
          `}</style>
          {galleryItems.map((g, i) => (
            <div
              key={i}
              className="relative overflow-hidden rounded group cursor-pointer mb-4"
              style={{ breakInside: 'avoid' }}
            >
              <img
                src={g.src}
                alt={g.caption}
                className="w-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div
                className="absolute inset-0 flex items-end p-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{ background: 'linear-gradient(to top, rgba(10,20,10,0.75) 0%, transparent 60%)' }}
              >
                <p className="text-white text-sm leading-snug">{g.caption}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── Contact / Booking ────────────────────────────────────────────────────────

function ContactBooking() {
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    dates: '',
    people: '',
    tour: '',
    message: '',
  })
  const [submitted, setSubmitted] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
  }

  const inputClass = "w-full px-4 py-3 rounded text-sm text-[#1a1a14] placeholder-[#a09a90] outline-none focus:ring-2 transition-all"
  const inputStyle = { backgroundColor: '#f5f0e8', border: '1px solid #d4cbbf', focusRingColor: '#2d5a27' } as React.CSSProperties

  return (
    <section id="contact" className="py-24" style={{ backgroundColor: '#ede8dc' }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col gap-4 mb-12">
          <div className="text-xs font-semibold tracking-widest uppercase text-[#8b5e3c]">Contact & Booking</div>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-[#1a1a14] leading-tight max-w-xl">
            Ready to hit <em>the trail?</em>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-16">
          {/* Form */}
          <div>
            {submitted ? (
              <div className="flex flex-col gap-4 p-8 rounded" style={{ backgroundColor: '#ffffff', border: '1px solid #d4cbbf' }}>
                <div className="text-[#2d5a27] text-4xl">✓</div>
                <h3 className="font-display text-2xl font-bold text-[#1a1a14]">Message received!</h3>
                <p className="text-[#4a4035]">Thank you for reaching out. Our team will get back to you within 24 hours to confirm your booking details.</p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="self-start text-sm font-semibold text-[#2d5a27] underline"
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#4a4035] mb-1.5 uppercase tracking-wide">Full Name *</label>
                    <input
                      required
                      type="text"
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      placeholder="Your name"
                      className={inputClass}
                      style={inputStyle}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#4a4035] mb-1.5 uppercase tracking-wide">Email *</label>
                    <input
                      required
                      type="email"
                      name="email"
                      value={form.email}
                      onChange={handleChange}
                      placeholder="you@email.com"
                      className={inputClass}
                      style={inputStyle}
                    />
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#4a4035] mb-1.5 uppercase tracking-wide">Phone</label>
                    <input
                      type="tel"
                      name="phone"
                      value={form.phone}
                      onChange={handleChange}
                      placeholder="+84 ..."
                      className={inputClass}
                      style={inputStyle}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#4a4035] mb-1.5 uppercase tracking-wide">Preferred Dates</label>
                    <input
                      type="text"
                      name="dates"
                      value={form.dates}
                      onChange={handleChange}
                      placeholder="e.g. 15–20 March 2025"
                      className={inputClass}
                      style={inputStyle}
                    />
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#4a4035] mb-1.5 uppercase tracking-wide">Number of People</label>
                    <input
                      type="number"
                      name="people"
                      min="1"
                      max="12"
                      value={form.people}
                      onChange={handleChange}
                      placeholder="1 – 12"
                      className={inputClass}
                      style={inputStyle}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#4a4035] mb-1.5 uppercase tracking-wide">Tour Interest</label>
                    <select
                      name="tour"
                      value={form.tour}
                      onChange={handleChange}
                      className={inputClass}
                      style={inputStyle}
                    >
                      <option value="">Select a tour...</option>
                      {tours.map((t) => <option key={t.id} value={t.title}>{t.title}</option>)}
                      <option value="custom">Custom / Not sure yet</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#4a4035] mb-1.5 uppercase tracking-wide">Message</label>
                  <textarea
                    name="message"
                    value={form.message}
                    onChange={handleChange}
                    rows={4}
                    placeholder="Tell us about your group, interests, or any questions..."
                    className={inputClass}
                    style={{ ...inputStyle, resize: 'vertical' }}
                  />
                </div>
                <button
                  type="submit"
                  className="mt-2 px-8 py-4 text-sm font-semibold rounded transition-all hover:opacity-90 active:scale-[0.98]"
                  style={{ backgroundColor: '#2d5a27', color: '#f5f0e8' }}
                >
                  Send Enquiry →
                </button>
              </form>
            )}
          </div>

          {/* Info */}
          <div className="flex flex-col gap-8">
            <div className="flex flex-col gap-5">
              {[
                {
                  icon: '📞',
                  label: 'Phone / WhatsApp',
                  value: '+84 905 123 456',
                  href: 'tel:+84905123456',
                },
                {
                  icon: '✉️',
                  label: 'Email',
                  value: 'hello@gialai-eco.vn',
                  href: 'mailto:hello@gialai-eco.vn',
                },
                {
                  icon: '📍',
                  label: 'Office',
                  value: '15 Nguyễn Văn Cừ, Pleiku, Gia Lai, Vietnam',
                  href: '#',
                },
              ].map((c) => (
                <div key={c.label} className="flex gap-4 items-start">
                  <span className="text-xl mt-0.5">{c.icon}</span>
                  <div>
                    <div className="text-xs text-[#7a6f60] uppercase tracking-wide mb-0.5">{c.label}</div>
                    <a href={c.href} className="text-[#1a1a14] font-medium hover:text-[#2d5a27] transition-colors">{c.value}</a>
                  </div>
                </div>
              ))}
            </div>

            {/* Map placeholder */}
            <div
              className="rounded overflow-hidden flex items-center justify-center"
              style={{ height: 220, backgroundColor: '#d4cbbf', border: '1px solid #c4bbb0' }}
            >
              <div className="text-center">
                <div className="text-3xl mb-2">🗺️</div>
                <p className="text-sm text-[#7a6f60]">Pleiku, Gia Lai, Vietnam</p>
                <a
                  href="https://maps.google.com/?q=Pleiku,Gia+Lai,Vietnam"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-semibold text-[#2d5a27] mt-1 inline-block underline"
                >
                  Open in Google Maps →
                </a>
              </div>
            </div>

            {/* Social links */}
            <div>
              <div className="text-xs text-[#7a6f60] uppercase tracking-wide mb-3">Follow our journey</div>
              <div className="flex gap-3">
                {[
                  { label: 'Facebook', icon: 'f', href: '#' },
                  { label: 'Instagram', icon: '◎', href: '#' },
                  { label: 'WhatsApp', icon: '✆', href: '#' },
                ].map((s) => (
                  <a
                    key={s.label}
                    href={s.href}
                    aria-label={s.label}
                    className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold transition-all hover:scale-110"
                    style={{ backgroundColor: '#2d5a27', color: '#f5f0e8' }}
                  >
                    {s.icon}
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

// ─── Footer ───────────────────────────────────────────────────────────────────

function Footer() {
  return (
    <footer style={{ backgroundColor: '#0e1e0e', color: 'rgba(255,255,255,0.7)' }}>
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-3 gap-12">
          {/* Brand */}
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ backgroundColor: '#2d5a27' }}>
                <LeafIcon className="w-4 h-4 text-[#f5f0e8]" />
              </div>
              <span className="font-display font-semibold text-white">Gialai Eco Tourist</span>
            </div>
            <p className="text-sm leading-relaxed">
              Sustainable, community-based adventure tourism in Gia Lai, Vietnam's Central Highlands. Licensed since 2012.
            </p>
          </div>

          {/* Links */}
          <div>
            <div className="text-xs font-semibold uppercase tracking-widest text-white mb-5">Quick Links</div>
            <div className="flex flex-col gap-3">
              {['Tour Packages', 'Destinations', 'About Us', 'Gallery', 'Contact'].map((l) => (
                <a key={l} href="#" className="text-sm hover:text-white transition-colors">{l}</a>
              ))}
            </div>
          </div>

          {/* Newsletter */}
          <div>
            <div className="text-xs font-semibold uppercase tracking-widest text-white mb-5">Stay Connected</div>
            <p className="text-sm mb-4">Get trail updates, new tour launches, and highland stories in your inbox.</p>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="your@email.com"
                className="flex-1 px-4 py-2.5 rounded text-sm text-[#1a1a14] outline-none"
                style={{ backgroundColor: '#f5f0e8' }}
              />
              <button
                className="px-4 py-2.5 rounded text-sm font-semibold text-white transition-colors"
                style={{ backgroundColor: '#2d5a27' }}
              >
                Subscribe
              </button>
            </div>
          </div>
        </div>

        <div
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mt-14 pt-6 text-xs"
          style={{ borderTop: '1px solid rgba(255,255,255,0.1)' }}
        >
          <span>© 2025 Gialai Eco Tourist. All rights reserved.</span>
          <span>Designed with care for the Central Highlands.</span>
        </div>
      </div>
    </footer>
  )
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  return (
    <div className="min-h-screen" style={{ backgroundColor: '#f5f0e8' }}>
      <Navbar />
      <Hero />
      <About />
      <TourPackages />
      <Destinations />
      <WhyChooseUs />
      <Gallery />
      <ContactBooking />
      <Footer />
    </div>
  )
}
